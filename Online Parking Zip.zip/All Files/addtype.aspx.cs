﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration; 

public partial class addtype : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into vehiletype values(@n,@cost)";
        comm=new SqlCommand(q,conn);
        comm.Parameters.AddWithValue("@n", TextBox1.Text);
        comm.Parameters.AddWithValue("@cost", TextBox2.Text);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Response.Write("<script>alert('Vehicle Type added successfully')</script>");
            TextBox1.Text = "";
            TextBox2.Text = "";

        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }

            

            }
    }
