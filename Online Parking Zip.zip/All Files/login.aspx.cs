﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "Select name from signup where Email=@un and Password=@p";
        comm=new SqlCommand(q,conn);
        comm.Parameters.AddWithValue("@un", TextBox4.Text);
        comm.Parameters.AddWithValue("@p", TextBox3.Text);
        
        conn.Open();
        object res = comm.ExecuteScalar();
        conn.Close();
        if (res == null)
        {
            Label1.Text="Please check Username/Password";
        }
        else
        {
            Session.Add("n", res.ToString());
            Session.Add("un", TextBox4.Text);
            q = "select UserType from signup where Email=@un";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@un", TextBox4.Text);
            
            conn.Open();
            res = comm.ExecuteScalar();
            conn.Close();
            if (res.ToString() == "admin")
            {
                Session.Add("ad", "admin");
                Response.Redirect("adminhome.aspx");
            }
            else if (res.ToString() == "guard")
            {
                Session.Add("gd", "guard");
                Response.Redirect("guardhome.aspx");
            }
            else
            {
                Response.Redirect("home.aspx");
            }
           
        }
      }
    }
