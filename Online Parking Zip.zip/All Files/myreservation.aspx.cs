﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class myreservation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 0)
        {
            Label2.Text = "No reservations found";
        }
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        Label mylbl;
        DateTime pdt;
        foreach (GridViewRow myrow in GridView1.Rows)
        {
            mylbl = (Label)myrow.Cells[4].FindControl("Label1");
            pdt = Convert.ToDateTime(mylbl.Text);

            if (pdt < DateTime.Now.Date)
            {
                myrow.Cells[9].Text = "";
            }

            if (myrow.Cells[8].Text == "Cancelled" || myrow.Cells[8].Text == "Completed")
            {
                myrow.Cells[9].Text = "";
            }


        }
    }
}