﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;
public partial class guardhome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            DropDownList1.Items.Insert(0, "Select");
            DropDownList2.Items.Insert(0, "Select");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "update parkingreservation set status=@st where parkingslot=@pslot and parkingdate=@dt";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@st", "Completed");
        comm.Parameters.AddWithValue("@pslot", DropDownList2.SelectedValue);
        comm.Parameters.AddWithValue("@dt", DateTime.Now.Date);

        conn.Open();
        comm.ExecuteNonQuery();
        conn.Close();
        Label2.Text = "Slot Vacated Successfully";
        
        fetchslots();
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    
        fetchslots();
    }
    void fetchslots()
    {
        DropDownList2.Items.Clear();
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "SELECT addslot.name, addslot.slotid FROM parkingreservation INNER JOIN addslot ON parkingreservation.parkingslot = addslot.slotid where parkingreservation.parkinglevel=@plvl and parkingreservation.parkingdate=@pdate and parkingreservation.status=@st";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@plvl", DropDownList1.SelectedValue);
        comm.Parameters.AddWithValue("@pdate", DateTime.Now.Date);
        comm.Parameters.AddWithValue("@st", "Booked");
        conn.Open();
        SqlDataReader myreader = comm.ExecuteReader();
        if (myreader.HasRows)
        {
            DropDownList2.DataSource = myreader;
            DropDownList2.DataValueField = "slotid";
            DropDownList2.DataTextField = "name";
         

            DropDownList2.DataBind();
        }
        else
        {
            DropDownList2.Items.Add("No Slots to vacate");
        }
        conn.Close();
    }
   
}