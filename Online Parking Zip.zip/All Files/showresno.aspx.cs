﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;
using System.Net.Mail;
public partial class showresno : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "SELECT parkingreservation.pid, parkingreservation.parkingdate, parkingreservation.name, parkingreservation.phone, parkingreservation.vehicleno, parkingreservation.reservationby, parkingreservation.reservationdt, vehiletype.name AS Expr1, addparkinglevel.levelname, addrow.rowname, addslot.name AS Expr2 FROM vehiletype INNER JOIN parkingreservation ON vehiletype.vehicleid = parkingreservation.vehicletype INNER JOIN addrow INNER JOIN addparkinglevel ON addrow.parkinglevel = addparkinglevel.levelid INNER JOIN addslot ON addrow.rowid = addslot.row ON parkingreservation.parkinglevel = addparkinglevel.levelid AND parkingreservation.parkingrow = addrow.rowid AND parkingreservation.parkingslot = addslot.slotid WHERE (parkingreservation.reservationby = @rby) ORDER BY parkingreservation.reservationdt DESC";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@rby", Session["un"].ToString());
            conn.Open();
            SqlDataReader myreader;
            myreader = comm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                Label3.Text = myreader["name"].ToString();
                Label4.Text = myreader["vehicleno"].ToString();
                Label5.Text = myreader["levelname"].ToString();
                Label6.Text = myreader["rowname"].ToString();
                Label7.Text = myreader["expr2"].ToString();
                Label8.Text = Convert.ToDateTime(myreader["parkingdate"].ToString()).ToShortDateString();
                Label2.Text = myreader["pid"].ToString();
            }
            MailMessage message = new MailMessage();
            SmtpClient smtpClient = new SmtpClient();
            try
            {
                MailAddress fromAddress = new MailAddress("smart.online.parking.sytsem@gmail.com");//please fill your gmail id from where you  need to send email to customers who will make reservation
                message.From = fromAddress;
                message.To.Add(Session["un"].ToString());
                message.Subject = "Booking Confirmation :: Mail from SmartParking";
                message.IsBodyHtml = true;
                message.Body = "Hello, <br/><br/> Thanks for booking your parking slot on our website. Your reservation number is " + myreader["pid"].ToString() + " <br/><br/> Team SmartParking";
                smtpClient.Host = "smtp.gmail.com";   // We use gmail as our smtp client
                smtpClient.Port = 587;
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = true;
                smtpClient.Credentials = new System.Net.NetworkCredential("smart.online.parking.sytsem@gmail.com", "Parking_123");//please fill your gmail id and password from where you  need to send email to customers who will make reservation
                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                Label9.Text = ex.Message;
            }
            myreader.Close();
            myreader.Dispose();
            conn.Close();
        }
    }
}