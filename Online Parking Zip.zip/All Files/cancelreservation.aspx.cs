﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration; 
using System.Net.Mail;
public partial class cancelreservation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "SELECT parkingreservation.pid, parkingreservation.parkingdate, parkingreservation.vehicleno, parkingreservation.reservationdt, addslot.name AS Expr1, addparkinglevel.levelname, addrow.rowname, vehiletype.name FROM parkingreservation INNER JOIN addslot ON parkingreservation.parkingslot = addslot.slotid INNER JOIN vehiletype ON parkingreservation.vehicletype = vehiletype.vehicleid INNER JOIN addparkinglevel ON parkingreservation.parkinglevel = addparkinglevel.levelid INNER JOIN addrow ON parkingreservation.parkingrow = addrow.rowid WHERE (parkingreservation.pid = @pid)";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@pid", Request.QueryString["resid"]); ;
        conn.Open();
        SqlDataReader myreader;
        myreader = comm.ExecuteReader();
        if (myreader.HasRows == true)
        {
            myreader.Read();
            Label2.Text = myreader["pid"].ToString();
            Label3.Text = myreader["name"].ToString();
            Label4.Text = myreader["vehicleno"].ToString();
            Label5.Text=myreader["levelname"].ToString()+ " in " + myreader["rowname"].ToString() + " at slot number " +myreader["expr1"].ToString() ;
            Label6.Text = myreader["parkingdate"].ToString();
        }
        myreader.Close();
        myreader.Dispose();
        conn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Response.Redirect("myreservation.aspx");
        Response.Redirect("home.aspx"); 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        string q = "update parkingreservation set status=@st where pid=@pid";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@st", "Cancelled");
        comm.Parameters.AddWithValue("@pid", Request.QueryString["resid"]);
        conn.Open();
        comm.ExecuteNonQuery();
        conn.Close();
        Label7.Text="Your reservation is cancelled";
        
        
        MailMessage message = new MailMessage();
        SmtpClient smtpClient = new SmtpClient();
        try
        {
            MailAddress fromAddress = new MailAddress("smart.online.parking.sytsem@gmail.com");//please fill your gmail id from where you  need to send email to customers who will make reservation
            message.From = fromAddress;
            message.To.Add(Session["un"].ToString());
            message.Subject = "Cancellation Confirmation :: Mail from SmartParking";
            message.IsBodyHtml = true;
            message.Body = "Hello, <br/> As requested by you, your parking reservation with reservation number " + Label2.Text + " has been cancelled <br/> Team SmartParking";
            smtpClient.Host = "smtp.gmail.com";   // We use gmail as our smtp client
            smtpClient.Port = 587;
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = true;
            smtpClient.Credentials = new System.Net.NetworkCredential("smart.online.parking.sytsem@gmail.com", "Parking_123");//please fill your gmail id and password from where you  need to send email to customers who will make reservation

            smtpClient.Send(message);
        }
        catch (Exception ex)
        {
            Label8.Text = ex.Message;
        }
        // CancelationThank
        Response.Redirect("CancelationThank.aspx");

    }
}