﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;using System.Configuration;

public partial class updateslotdetails : System.Web.UI.Page
{
    string lvlid,row,vtype;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "select * from addslot where slotid=@sltid";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@sltid", Request.QueryString["sid"]);
            conn.Open();
            SqlDataReader myreader;
            myreader = comm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                TextBox1.Text = myreader["name"].ToString();
                lvlid = myreader["level"].ToString();
                row=myreader["row"].ToString();
                vtype = myreader["vehicletype"].ToString();
            }
            conn.Close();

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "update addslot set name=@rownam,level=@lvl,row=@rw,vehicletype=@vt where slotid=@sid";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@rownam", TextBox1.Text);
        comm.Parameters.AddWithValue("@lvl",DropDownList1.SelectedValue);
        comm.Parameters.AddWithValue("@rw",DropDownList2.SelectedValue);
        comm.Parameters.AddWithValue("vt", DropDownList3.SelectedValue);
        comm.Parameters.AddWithValue("@sid", Request.QueryString["sid"]);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Label1.Text = "Slot updated successfully";
        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("updateslot.aspx");
    }
   
    protected void DropDownList3_DataBound(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            DropDownList3.Items.FindByValue(vtype).Selected = true;
        }
    }
    protected void DropDownList2_DataBound(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            DropDownList2.Items.FindByValue(row).Selected = true;
        }
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            DropDownList1.Items.FindByValue(lvlid).Selected = true;
        }
    }
}
