﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration; 

public partial class addparkinglevel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into addparkinglevel values(@n)";
        comm=new SqlCommand(q,conn);
        comm.Parameters.AddWithValue("@n", TextBox1.Text);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Response.Write("<script>alert('Parking Level added successfully')</script>");
            TextBox1.Text = "";
            GridView1.DataBind();

        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }

        }
    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 0)
        {
            Label2.Text = "No levels available";
        }
        else
        {
            Label2.Text = "";
        }
    }
  
}
