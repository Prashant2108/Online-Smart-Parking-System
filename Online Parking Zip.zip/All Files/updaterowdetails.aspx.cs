﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;using System.Configuration;

public partial class updaterowdetails : System.Web.UI.Page
{
    string llid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "select * from addrow where rowid=@rwid";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@rwid", Request.QueryString["rid"]);
            conn.Open();
            SqlDataReader myreader;
            myreader = comm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                TextBox1.Text = myreader["rowname"].ToString();
                llid = myreader["parkinglevel"].ToString();
            }
            //myreader.Close();
            //myreader.Dispose();
            conn.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "update addrow set rowname=@rownam,parkinglevel=@plvl where rowid=@rid";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@rownam", TextBox1.Text);
        comm.Parameters.AddWithValue("@plvl",DropDownList1.SelectedValue);
        comm.Parameters.AddWithValue("@rid", Request.QueryString["rid"]);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Label1.Text = "Row updated successfully";
        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect ("updaterow.aspx");
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        if(Page.IsPostBack==false)
        {
            DropDownList1.Items.FindByValue(llid).Selected=true;
        }
    }
}