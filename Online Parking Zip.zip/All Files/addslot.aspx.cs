﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;

public partial class addslot : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into addslot values(@nm,@level,@row,@vehicletype)";
        comm=new SqlCommand(q,conn);
        comm.Parameters.AddWithValue("@nm", TextBox1.Text);
        comm.Parameters.AddWithValue("@level",DropDownList1.SelectedValue);
        comm.Parameters.AddWithValue("@row",DropDownList2.SelectedValue);
        comm.Parameters.AddWithValue("@vehicletype",DropDownList3.SelectedValue);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Response.Write("<script>alert('Parking slot added successfully')</script>");
            TextBox1.Text = "";

        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }

            

            }
    }
