﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;


public partial class signup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "select name from signup where Email=@un";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@un", TextBox6.Text);
        conn.Open();
        object res = comm.ExecuteScalar();
        conn.Close();
        if (res == null)
        {
            q = "insert into signup values(@n,@add,@st,@ph,@un,@p,@gen,@ut)";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@n", TextBox1.Text);
            comm.Parameters.AddWithValue("@add", TextBox2.Text);
            comm.Parameters.AddWithValue("@st", TextBox4.Text);
            comm.Parameters.AddWithValue("@ph", TextBox5.Text);
            comm.Parameters.AddWithValue("@un", TextBox6.Text);
            comm.Parameters.AddWithValue("@p", TextBox7.Text);
            comm.Parameters.AddWithValue("@gen", RadioButtonList1.SelectedItem.Text);
            comm.Parameters.AddWithValue("@ut", "normal");
            conn.Open();
            int res1 = comm.ExecuteNonQuery();
            conn.Close();
            if (res1 == 1)
            {
                Response.Redirect("wc.aspx");
            }
            else
            {
                Label1.Text = "There seems to be some error please try again";
            }
        }
        else
        {
            Label1.Text = "User with this email id already exists";
        }
    }
}