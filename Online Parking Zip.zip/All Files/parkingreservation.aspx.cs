﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;

public partial class parkingreservation : System.Web.UI.Page
{
    double cost;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("problem.aspx");
        }
        if(Page.IsPostBack==false)
        {
           //TextBox12.Text = DateTime.Now.Date.ToShortDateString();
           

        }
        TextBox12_CalendarExtender.StartDate = DateTime.Now;
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (DropDownList1.SelectedIndex > 0)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "select cost from vehiletype where vehicleid=@vid";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@vid", DropDownList1.SelectedValue);
            conn.Open();
            Label2.Text = comm.ExecuteScalar().ToString();
            conn.Close();
        }
        else
        {
            Label2.Text = "Choose Vehicle Type";
            Panel1.Visible = false;
        }
       
     

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "select pid from parkingreservation where parkingslot=@pslot and parkingdate=@pdate and status=@st";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@pslot", DropDownList2.SelectedItem.Text);
        comm.Parameters.AddWithValue("@pdate", TextBox12.Text);
        comm.Parameters.AddWithValue("@st", "Booked");
    
        conn.Open();
        object res = comm.ExecuteScalar();
        conn.Close();

        if (res == null)
        {
            Panel1.Visible = true;
        }
        else
        {
            Label3.Text = "This slot is already reserved, please choose another slot";
            Panel1.Visible = false;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            Panel2.Visible = true;
        }
        else
        {
            Panel2.Visible = false;
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        string q = "insert into parkingreservation values(@vehicletype,@parkinglevel,@parkingrow,@parkingslot,@parkingdate,@nm,@ph,@vehicleno,@ccno,@cccom,@cchol,@expiry,@mode,@un,@rdt,@st)";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@vehicletype", DropDownList1.SelectedValue);
        comm.Parameters.AddWithValue("@parkinglevel", DropDownList3.SelectedValue);
        comm.Parameters.AddWithValue("@parkingrow", DropDownList4.SelectedValue);
        comm.Parameters.AddWithValue("@parkingslot", DropDownList2.SelectedValue);
        comm.Parameters.AddWithValue("@parkingdate", TextBox12.Text);
        comm.Parameters.AddWithValue("@nm", TextBox1.Text);
        comm.Parameters.AddWithValue("@ph", TextBox2.Text);
        comm.Parameters.AddWithValue("@vehicleno", TextBox3.Text);
        comm.Parameters.AddWithValue("@ccno", TextBox8.Text);
        comm.Parameters.AddWithValue("@cccom", DropDownList5.SelectedValue);
        comm.Parameters.AddWithValue("@cchol", TextBox9.Text);
        comm.Parameters.AddWithValue("@expiry", TextBox10.Text);
        comm.Parameters.AddWithValue("@mode", RadioButtonList1.SelectedItem.Text);
        comm.Parameters.AddWithValue("@un", Session["un"].ToString());
        comm.Parameters.AddWithValue("@rdt", DateTime.Now);
        comm.Parameters.AddWithValue("@st", "Booked");
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Response.Redirect("showresno.aspx");
        }
        else
        {
            Label4.Text = "There seems to be some error please try again";
        }
    }
    
    protected void DropDownList2_DataBound(object sender, EventArgs e)
    {
        if (DropDownList2.Items.Count == 0)
        {
            DropDownList2.Items.Add("No slots");
            Button1.Enabled = false;
        }
        else
        {
            Button1.Enabled = true;
        }
       removeslots();  
    }
    void removeslots()
    {
        if (DropDownList4.Items.Count > 0)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "select parkingslot from parkingreservation where parkingrow=@prow and parkingdate=@pdate and status=@st";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@prow", DropDownList4.SelectedValue);
            comm.Parameters.AddWithValue("@pdate", TextBox12.Text);
            comm.Parameters.AddWithValue("@st", "Booked");
            conn.Open();
            SqlDataReader myreader = comm.ExecuteReader();
            if (myreader.HasRows)
            {
                while (myreader.Read())
                {
                    ListItem myitem;
                    myitem = DropDownList2.Items.FindByValue(myreader["parkingslot"].ToString());
                    DropDownList2.Items.Remove(myitem);
                }
            }
            else
            {

            }
            conn.Close();
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       
        double dis;
        SqlCommand comm;
        SqlConnection conn;

        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        string q = "select cost from vehiletype where vehicleid=@vid";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@vid", DropDownList1.SelectedValue);
        conn.Open();
        cost = Convert.ToDouble(comm.ExecuteScalar().ToString());
        conn.Close();

        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        q = "select cost from addcoupon where couponcode=@cc";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@cc", TextBox11.Text);
        conn.Open();
        SqlDataReader myreader = comm.ExecuteReader();

        if (myreader.HasRows)
        {
            myreader.Read();
            dis = Convert.ToDouble(myreader["cost"].ToString());
            double disamt = (dis * cost) / 100;
            double ra = cost - disamt;
            Label2.Text = ra.ToString();
            Label5.Text = "Discount Code applied successfully";
        }
        else
        {
            Label5.Text = "Invalid Coupon Code";
            Label2.Text = cost.ToString();
        }
        conn.Close();
    }
    protected void TextBox12_TextChanged(object sender, EventArgs e)
    {
        DropDownList2.DataBind();
        removeslots();
    }


}
