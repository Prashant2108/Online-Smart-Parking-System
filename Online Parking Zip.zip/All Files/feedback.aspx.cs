﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;

public partial class feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into feedback values(@n,@em,@ph,@wbo,@wbd,@wbr,@urf,@in,@sug,@fd)";
        comm = new SqlCommand(q, conn);
        
        comm.Parameters.AddWithValue("@n", TextBox1.Text);
        comm.Parameters.AddWithValue("@em", TextBox2.Text);
        comm.Parameters.AddWithValue("@ph", TextBox3.Text);
        comm.Parameters.AddWithValue("@wbo", RadioButtonList1.SelectedItem.Text);
        comm.Parameters.AddWithValue("@wbd", RadioButtonList2.SelectedItem.Text);
        comm.Parameters.AddWithValue("@wbr", RadioButtonList3.SelectedItem.Text);
        comm.Parameters.AddWithValue("@urf", RadioButtonList4.SelectedItem.Text);
        comm.Parameters.AddWithValue("@in", TextBox4.Text);
        comm.Parameters.AddWithValue("@sug", TextBox5.Text);
        comm.Parameters.AddWithValue("@fd", DateTime.Now);

        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 0)
        {
            Label1.Text = "There seems to be some error please try again";
        }
        else
        {
            Response.Redirect("feedbackthnks.aspx");
        }
    }
}