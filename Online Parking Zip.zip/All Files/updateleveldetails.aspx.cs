﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;using System.Configuration; 

public partial class updateleveldetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlCommand comm;
            SqlConnection conn;
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            String q = "select * from addparkinglevel where levelid=@levelid";
            comm = new SqlCommand(q, conn);
            comm.Parameters.AddWithValue("@levelid", Request.QueryString["lid"]);
            conn.Open();
            SqlDataReader myreader;
            myreader = comm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                TextBox1.Text = myreader["levelname"].ToString();
            }
            myreader.Close();
            myreader.Dispose();
            conn.Close();

        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("updatelevel.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "update addparkinglevel set levelname=@levelnam where levelid=@levelid";  
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@levelnam",TextBox1.Text);
        comm.Parameters.AddWithValue("@levelid",Request.QueryString["lid"]);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        if (res == 1)
        {
            Label1.Text = "Level updated successfully";
        }
        else
        {
            Label1.Text = "There seems to be some error please try again";
        }
   
    }
}