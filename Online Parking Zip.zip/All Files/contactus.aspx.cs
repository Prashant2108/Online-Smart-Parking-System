﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration;

public partial class contactus : System.Web.UI.Page
{
    
    protected void Button1_Click(object sender, EventArgs e)
    {
         SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into contactus values(@dt,@n,@em,@ph,@msg)";
        comm=new SqlCommand(q,conn);
        comm.Parameters.AddWithValue("@dt",DateTime.Now);
        comm.Parameters.AddWithValue("@n", TextBox2.Text);
        comm.Parameters.AddWithValue("@em",TextBox3.Text);
        
        comm.Parameters.AddWithValue("@ph", TextBox4.Text);
        comm.Parameters.AddWithValue("@msg", TextBox5.Text);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("contactusthnk.aspx");
        //Label1.Text = "Thank You for contacting us.";
    }
   
}
