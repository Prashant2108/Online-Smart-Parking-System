﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;using System.Configuration; using System.Configuration; 

public partial class addcoupon : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm;
        SqlConnection conn;
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        String q = "insert into addcoupon values(@cc,@cost)";
        comm = new SqlCommand(q, conn);
        comm.Parameters.AddWithValue("@cc", TextBox1.Text);
        comm.Parameters.AddWithValue("@cost", TextBox2.Text);
        conn.Open();
        int res = comm.ExecuteNonQuery();
        conn.Close();
        Label1.Text = "Discount Code Added Successfully";
        GridView1.DataBind();
            
    }
}